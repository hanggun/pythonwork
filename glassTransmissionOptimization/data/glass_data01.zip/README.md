# Overview over the data #

## periods.csv ##
- period: id number
- month: name of period

## inputGrades.csv ##

- id: id of input grade

## outputGrades.csv ##

- id: id of output grade

## collectionAreas.csv ##

- id:			id of collection area
- massLoss:		expected loss in this collection area

## collectedGrades_period.csv ##

- period: id of period
- areaId: id of collection area
- inputGradeId: id of input grade
- amount: mass of input grade in collection area in tonnes per period

## processingFacilities.csv ##

- id: id of processing facility
- capPerMonth: capacity of the processing facility in tonnes per month

## convertBalance.csv ##

- facilityId:		id of processing facility
- inputGradeId:		id of input grade
- outputGradeId:		id of output grade
- massBalanceFactor:	conversion factor (mass of output grade = mass of input grade * massBalanceFactor)


## quantityScaleBids.csv ##

- facilityId:		id of processing facility
- minOfScale:		minimum amount for which the bid is valid
- maxOfScale:		maximum amount for which the bid is valid
- costOfProcessing:	bid in price per tonne


## customerFactories.csv ##

- id:			id of factory
- minDemand:		minimum amount to deliver to factory


## requestedGrades.csv ##

- factoryId:		id of customer factory
- outputGradeId:	id of output grade
- amount:			demand in tonnes of this output grade for this factory 
- priceOfSale:		price per tonne of this output grade for this factory
- absVariation:		allowed variation in demand


## requestedGrades_period.csv ##
- period:			id of period
- outputGradeId:	id of output grade
- factoryId:		id of customer factory
- amount:			maximal amount that the factory can process in this period in tonnes.


## preCarriageBid.csv ##

- areaId:			id of collection area
- facilityId:		id of processing facility
- costOfTransport:	cost of transporting one tonne from collection area to facility



## postCarriageBid.csv ##

- facilityId:		id of processing facility
- factoryId:		id of customer factory
- costOfTransport:	cost of transporting one tonne from processing facility to customer factory


